(function() {
  'use strict'


  angular
    .module("myapp", [])
    .filter('bytwo', bytwo);

  function bytwo(){
    return function(input) {
      return (input)*2;
    };
  }

})();




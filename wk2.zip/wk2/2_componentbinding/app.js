(function() {
    'use strict'

    var helloComponent = {
        bindings:{
            name: "="
        },
        template : "Hello {{$ctrl.name}}",
    };

    angular
        .module("myapp", [])
        .component("hello", helloComponent);

})();
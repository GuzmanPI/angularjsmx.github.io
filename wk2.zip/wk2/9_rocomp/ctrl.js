(function(){
  'use strict';

  var character = {
     bindings:{
       detail : '='
     },
    'templateUrl' : './character.html',
  };

  angular
    .module('myapp')
    .component("character",character)
    .controller("homeCtrl", homeCtrl)
    .factory("apiStarwars", apiStarwars);

    apiStarwars.$inject = ["$resource"];
    function apiStarwars($resource){
      return $resource("http://swapi.co/api/people/:id/");
    }

  function homeCtrl(){
    var home = this;

    home.people = [
      {name:'Darth Vader ', id: 4, img: 'http://thumbs.imagekind.com/3134454_200/Darth-Vader_art.jpg'},
      {name:'Luke ', id: 1, img: 'http://www.microsiervos.com/images/luke-skystupid.jpg'},
      {name:'Obi Wan', id: 10,img: 'http://rs200.pbsrc.com/albums/aa183/erja_esko/Star%20Wars%20Qui%20Gon%20Jinn%20und%20Obi%20Wan%20Kenobi/ObiWanKenobiAOTCV2.jpg~c200'}

    ];
  }

})();
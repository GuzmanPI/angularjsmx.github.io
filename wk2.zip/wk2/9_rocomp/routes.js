(function(){
  'use strict';

  angular
    .module('myapp')
    .config(config);

  config.$inject = ["$routeProvider"];

  function config($routeProvider){
    $routeProvider
      .when('/',{
        templateUrl: './home.html',
        controller: 'homeCtrl',
        controllerAs: 'home',
      })
      .when('/character/:id',{
        template:' <character detail="$resolve.detailCharacter"></character>',
        resolve : {
          detailCharacter : getCharacter
        }
      })
      .otherwise({
        redirectTo : '/'
      });
  }

  getCharacter.$inject = ["$route","apiStarwars"];
  function getCharacter($route, apiStarwars){
    return apiStarwars.get({'id': $route.current.params.id});
  }
})();
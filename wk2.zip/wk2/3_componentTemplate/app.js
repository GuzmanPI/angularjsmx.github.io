(function() {
    'use strict'

    var helloComponent = {
        bindings:{
            name: "="
        },
        replace : true,
        templateUrl : "./hello.html",
    };

    angular
        .module("myapp", [])
        .component("hello", helloComponent);

})();
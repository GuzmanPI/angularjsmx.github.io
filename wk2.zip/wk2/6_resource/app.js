(function() {
  'use strict'

  angular
    .module("myapp", ["ngResource"])
    .controller("starWars", starWars)
    .factory("apiStarwars", apiStarwars);

  apiStarwars.$inject = ["$resource"];
  function apiStarwars($resource){
    return $resource("http://swapi.co/api/people/:id/");
  }

  starWars.$inject = ["apiStarwars"];
  function starWars(apiStarwars){
    var star = this;
    star.character = apiStarwars.get({'id':4});
  }

})();
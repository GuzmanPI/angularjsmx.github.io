(function() {
    'use strict'

    var helloComponent = {
        bindings:{
            name: "<",
            number : "="

        },
        templateUrl : "./hello.html"
    };

    angular
      .module("myapp", [])
      .controller("homeCtrl", homeCtrl)
      .component("hello", helloComponent);


    function homeCtrl(){
        var home = this;
        home.users = [
            {name: 'Josue',    number : Math.random()},
            {name: 'Xochitl',  number : Math.random()},
            {name: 'David',    number : Math.random()}
        ];
    }

})();
(function() {
  'use strict'

  var helloComponent = {
    bindings:{
      name: "<",
      number : "="

    },
    templateUrl : "./hello.html",
    controller: helloCtrl
  };

  angular
    .module("myapp", [])
    .controller("homeCtrl", homeCtrl)
    .component("hello", helloComponent);


  function homeCtrl(){
    var home = this;
    home.users = [
      {name: 'Josue',    number : Math.random()},
      {name: 'Xochitl',  number : Math.random()},
      {name: 'David',    number : Math.random()}
    ];
  }

  function helloCtrl(){
    var hello = this;
    hello.click = click;

    function click(){
      hello.number = Math.random();
    }
  }

})();
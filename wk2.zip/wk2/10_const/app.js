(function() {
  'use strict'

  var myconfig= {
    'url': 'http://google.com',
    'port':'80',
  };

  angular
    .module("myapp", [])
    .constant("myconfig",myconfig)
    .controller("homeCtrl",homeCtrl);


  homeCtrl.$inject = ["myconfig"];
  function homeCtrl(myconfig){
    var home = this;
    home.config = myconfig;
  }
})();



(function() {
    'use strict'

    var helloComponent = {
        template : "Hello"
    };

    angular
        .module("myapp", [])
        .component("hello", helloComponent);

})();
(function(){
  'use strict';

  angular
    .module('myapp', [])
    .service('myService', myService);

  function myService(){

    return {
      'attr': null,
      'method': method
    };

    function method(){

    }
  }

})();
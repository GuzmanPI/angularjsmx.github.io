(function(){
  'use strict';
  
  angular.module('myapp',[] )
    .directive('myUser',myUser);
    
  function myUser(){
      var directive = {
        restrict: 'EA',
        templateUrl: './directive.html',
        controller: directiveController,
        controllerAs: 'user',
        replace : true
      };
      return directive;
  }

  function directiveController(){
    var user = this;
    user.name = "Josue";
    user.change = change;

    function change(){
      user.name = "Gerardo";
    }
  }


})();
(function(){
  'use strict';

  angular.module('myapp',[] )
    .controller('userCtrl',userCtrl);

  function userCtrl(){
    var user = this;
    user.add =  add;
    user.list = [];

    function add(){
      console.log('here');
      user.list.push(user.name);
    }
  }

})();
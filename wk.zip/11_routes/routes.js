(function(){
  'use strict';

  angular
    .module('myapp')
    .config(config);

  config.$inject = ["$routeProvider"];

  function config($routeProvider){
    $routeProvider
      .when('/',{
        templateUrl: './home.html',
        controller: 'HomeController',
        controllerAs: 'home',
      })
      .when('/otro',{
        templateUrl: './otro.html',
        controller: 'OtherController',
        controllerAs: 'other',
      })
      .otherwise({
        redirectTo : '/'
      });
  }
})();
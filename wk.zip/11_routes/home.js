(function(){
  'use strict';

  angular
    .module('myapp')
    .controller('HomeController', homeController);

  function homeController(){
    var home = this;
    home.hi = "HOLA";
  }
})();
(function(){
  'use strict';

  angular
    .module('myapp',[])
    .controller('myController', myController)
    .directive('hiUser', user);

  function myController(){
    var ctrl = this;
    ctrl.user = {'name':'Josue','lastname':'Gutierrez'};
  }

  function user(){
    var directive = {
      restrict: 'EA',
      template: 'Hola {{ctrl.user.name}} {{ctrl.user.lastname}}',
    };
    return directive;
  }


})();
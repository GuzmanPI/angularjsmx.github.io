(function(){
  'use strict';

  angular
    .module('myapp',[])
    .directive('miElemento', miElemento);

  function miElemento(){
      var directive = {
        restrict: 'EA',
        template: '<h1>Hola mundo</h1>',
      };
      return directive;
  }


})();
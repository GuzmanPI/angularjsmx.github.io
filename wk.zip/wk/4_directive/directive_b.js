(function(){
  'use strict';

  angular
    .module('myapp',[])
    .controller('myController', myController)
    .directive('hiUser', user);

  function myController(){
    var ctrl = this;
    ctrl.users = [
      {'name':'Josue','lastname':'Gutierrez'},
      {'name':'Juan' ,'lastname':'Godinez'},
    ];
  }

  function user(){
    var directive = {
      restrict: 'EA',
      template: 'Hola {{user.name}} {{user.lastname}}',
    };
    return directive;
  }


})();
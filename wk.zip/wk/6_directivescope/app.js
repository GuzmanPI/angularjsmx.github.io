(function(){
  'use strict';

  angular
    .module("myapp",[])
    .controller("userCtrl", userCtrl)
    .directive("userCard", uCard);

  function userCtrl(){
    var uctrl = this;

    uctrl.users = [
      {'name':'Josue','lastname':'Gutierrez','age':20},
      {'name':'Juan' ,'lastname':'Godinez', 'age': 22}
    ];

    uctrl.addAge = addAge;

    function addAge(index){
      uctrl.users[index].age+=1;
    }
  }

  function uCard(){
      var directive = {
        restrict: 'EA',
        templateUrl: './card.html',
        scope : {
            userEqual : '=',
            userAt : '@',
            index : '=',
            click : '&addAge'
        },
        controller: uCard,
        controllerAs: 'card',
        bindToController: true,
        replace : true
      };
      return directive;
  }

})();
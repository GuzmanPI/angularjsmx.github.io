(function(){
  'use strict';

  angular
    .module("myapp", [])
    .controller("starwars", starwars);

  starwars.$inject = ["$http"];
  function starwars($http){
    var sw = this;
    sw.character = null;

    $http({
        method: "GET",
        url : "http://swapi.co/api/people/1/"

    }).then( successSW, failSW);

    function successSW(data){
      sw.character = data;
    }

    function failSW(error){
      console.log(error);
    }
  }

})();
(function(){
  'use strict';

  angular.module('myapp',[] )
    .controller('demoCtrl',demoCtrl);

  function demoCtrl(){
    var demo = this;
    demo.message = "Hello";
    demo.changeMessage = changeMessage;

    function changeMessage(){
      demo.message = "Bye";
    }

  }

})();
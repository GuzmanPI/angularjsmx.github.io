(function(){
  'use strict';

  angular.module('myapp',[])
    .controller('userCtrl', userCtrl );

  function userCtrl(){
    var uctrl = this;
    uctrl.save = save;

    function save(){
      console.log(uctrl.user);
    }
  }
})();
(function(){
  'use strict';

  angular
    .module('myapp')
    .controller('otroController', otroController);

  function otroController(){
    var otro = this;
    otro.number = 1982390182093812;
  }
})();
(function(){
  'use strict';

  angular
    .module('myapp')
    .directive('appCart', appCart);

  function appCart(){
      var directive = {
        restrict: 'EA',
        templateUrl: './cart.html',
        controller: cartController,
        controllerAs: 'order',
        replace : true
      };
      return directive;
  }

  cartController.$inject= ['cartservice'];
  function cartController(cartservice){
    var order= this;
    order.cart = cartservice;
  }

})();
(function(){
  'use strict';

  angular
    .module('myapp')
    .directive('itemList', itemList);

  function itemList(){
    var directive = {
      restrict: 'EA',
      templateUrl: './itemlist.html',
      controller: itemController,
      controllerAs: 'items',
      replace : true
    };
    return directive;
  }


  itemController.$inject= ['cartservice'];

  function itemController(cartservice){
    var items = this;

    items.cart = cartservice;

    items.list = [
      {'id':'pz','name':'Pizza'},
      {'id':'al','name':'Alitas'},
      {'id':'hm','name':'Hamburguesa'},
      {'id':'en','name':'Ensalada'}
    ];
  }



})();
describe('app user add', appuseradd);


  function appuseradd(){
    it('should add 100 user', should_add_user);

    function should_add_user(){
      browser.get("http://localhost:8000/");

      for(var i = 1;i <= 100; i++) {
        element(by.model("user.name")).clear();
        element(by.model("user.name")).sendKeys("hola"+i);
        element(by.id('button')).click();
      }

      var list = element.all( by.repeater("u in user.list"));
      expect(list.count()).toEqual(100);
    }

  }
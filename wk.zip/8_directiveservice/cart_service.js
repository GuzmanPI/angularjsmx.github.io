(function(){
  'use strict';

  angular.module('myapp')
    .service('cartservice', cartservice);

  function cartservice(){

    return {
      'items': {},
      'addItem' : addItem,
    };

    function addItem(item){
      if( this.items[item.id] ){
        this.items[item.id].quantity+=1;
      }else{
        this.items[item.id] = {'name':item.name,'quantity':1};
      }
    }

  }

})();
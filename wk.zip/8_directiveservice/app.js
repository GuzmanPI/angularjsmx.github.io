(function(){
  'use strict';
  
  angular.module('myapp',[] );


})();
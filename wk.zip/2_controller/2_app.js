(function(){
  'use strict';

  angular.module('myapp',[] )
    .controller('demoCtrl',demoCtrl);
    
  function demoCtrl(){
    var demo = this;
    demo.say_hi = "Hello World";
  }

})();
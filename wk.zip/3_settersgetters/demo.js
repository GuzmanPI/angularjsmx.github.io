(function(){
  'use strict';

  angular.module('myapp')
    .controller('demoCtrl', demoCtrl);

  function  demoCtrl(){

  }

})();
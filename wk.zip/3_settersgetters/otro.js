(function(){
  'use strict';

  angular.module('myapp')
    .controller('otroCtrl', otroCtrl);

  function  otroCtrl(){

  }

})();